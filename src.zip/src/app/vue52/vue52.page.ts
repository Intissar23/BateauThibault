import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';

import {
  IonHeader,
  IonToolbar,
  IonTitle,
  IonButtons,
  IonBackButton,
  IonContent,
  IonList,
  IonItem,
  IonLabel,
  IonButton
} from '@ionic/angular/standalone';

import { RouterLink } from '@angular/router';
import { ProductService } from '../services/product';
import { CartService } from '../services/cart';

@Component({
  selector: 'app-vue52',
  standalone: true,
  templateUrl: './vue52.page.html',
  styleUrls: ['./vue52.page.scss'],
  imports: [
    CommonModule,
    RouterLink,
    IonHeader,
    IonToolbar,
    IonTitle,
    IonButtons,
    IonBackButton,
    IonContent,
    IonList,
    IonItem,
    IonLabel,
    IonButton
  ]
})
export class Vue52Page implements OnInit {

  products: any[] = [];

  constructor(
    private productService: ProductService,
    public cartService: CartService   // 💡 accessible dans le HTML
  ) {}

  ngOnInit() {
    this.productService.getAllProducts().subscribe({
      next: (data) => {
        // Catégorie 2 = Crustacés
        this.products = data.filter((p: any) => p.category === 2);
        console.log('Catégorie 2 (Crustacés) :', this.products);
      },
      error: (err) => {
        console.error('Erreur API :', err);
      }
    });
  }

  // Clic sur la ligne (si tu gardes le (click) sur <ion-item>)
  onProductClick(product: any) {
    console.log('Produit cliqué (Vue52) :', product);
  }

  // Bouton "Ajouter" (si tu veux l’appeler depuis le HTML)
  addToCart(product: any) {
    this.cartService.addToCart(product);
    console.log('Ajouté au panier (Vue52) :', product);
  }
}
