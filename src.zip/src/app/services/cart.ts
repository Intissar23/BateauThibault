import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CartService {

  cart: any[] = [];

  constructor() {}

  addToCart(product: any) {
    const found = this.cart.find(p => p.id === product.id);

    if (found) {
      found.qty += 1;
    } else {
      this.cart.push({ ...product, qty: 1 });
    }
  }

  removeFromCart(product: any) {
    this.cart = this.cart.filter(p => p.id !== product.id);
  }

  decreaseQty(product: any) {
    const found = this.cart.find(p => p.id === product.id);

    if (found) {
      found.qty -= 1;
      if (found.qty <= 0) {
        this.removeFromCart(product);
      }
    }
  }

  getCart() {
    return this.cart;
  }

  getTotal() {
    return this.cart.reduce((sum, p) => sum + (p.price * p.qty), 0);
  }
}
