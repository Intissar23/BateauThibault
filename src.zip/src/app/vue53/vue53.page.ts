import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';

import {
  IonHeader,
  IonToolbar,
  IonTitle,
  IonButtons,
  IonBackButton,
  IonContent,
  IonList,
  IonItem,
  IonLabel,
  IonButton
} from '@ionic/angular/standalone';

import { RouterLink } from '@angular/router';
import { ProductService } from '../services/product';
import { CartService } from '../services/cart';  // ✅ AJOUT IMPORTANT

@Component({
  selector: 'app-vue53',
  standalone: true,
  templateUrl: './vue53.page.html',
  styleUrls: ['./vue53.page.scss'],
  imports: [
    CommonModule,
    RouterLink,
    IonHeader,
    IonToolbar,
    IonTitle,
    IonButtons,
    IonBackButton,
    IonContent,
    IonList,
    IonItem,
    IonLabel,
    IonButton // ✅ pour <ion-button>
  ]
})
export class Vue53Page implements OnInit {

  products: any[] = [];

  constructor(
    private productService: ProductService,
    public cartService: CartService  // ✅ injection du service panier
  ) {}

  ngOnInit() {
    this.productService.getAllProducts().subscribe({
      next: (data) => {
        // Filtrer produits en promotion (sale = true)
        this.products = data.filter((p: any) => p.sale === true);
        console.log('Produits en promo :', this.products);
      },
      error: (err) => {
        console.error('Erreur API :', err);
      }
    });
  }

  // ➜ Quand on clique sur un produit
  onProductClick(product: any) {
    console.log('Produit cliqué (Vue53) :', product);
  }

  // ➜ AJOUT : Ajouter au panier
  addToCart(product: any) {
    this.cartService.addToCart(product);
    console.log("Ajouté au panier :", product);
  }
}
