import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';

import {
  IonHeader,
  IonToolbar,
  IonTitle,
  IonButtons,
  IonBackButton,
  IonContent,
  IonList,
  IonItem,
  IonLabel,
  IonButton
} from '@ionic/angular/standalone';

import { RouterLink } from '@angular/router';
import { ProductService } from '../services/product';
import { CartService } from '../services/cart';  // ✅ IMPORTANT

@Component({
  selector: 'app-vue51',
  standalone: true,
  templateUrl: './vue51.page.html',
  styleUrls: ['./vue51.page.scss'],
  imports: [
    CommonModule,
    RouterLink,
    IonHeader,
    IonToolbar,
    IonTitle,
    IonButtons,
    IonBackButton,
    IonContent,
    IonList,
    IonItem,
    IonLabel,
    IonButton  // ✅ Nécessaire pour <ion-button>
  ]
})
export class Vue51Page implements OnInit {

  products: any[] = [];

  // ⬇️ Injection du CartService pour ajouter un produit au panier
  constructor(
    private productService: ProductService,
    public cartService: CartService   // ✅ NE PAS OUBLIER
  ) {}

  ngOnInit() {
    this.productService.getAllProducts().subscribe({
      next: (data) => {
        // Filtrer catégorie = 1 (Coquillages / Huîtres)
        this.products = data.filter((p: any) => p.category === 1);
        console.log('Catégorie 1 (Coquillages / Huîtres) :', this.products);
      },
      error: (err) => {
        console.error('Erreur API :', err);
      }
    });
  }

  // ➜ Fonction clic sur un produit
  onProductClick(product: any) {
    console.log("Produit cliqué (Vue51) :", product);
  }

  // ➜ Fonction pour AJOUTER AU PANIER
  addToCart(product: any) {
    this.cartService.addToCart(product);
    console.log("AJOUT AU PANIER :", product);
  }
}
