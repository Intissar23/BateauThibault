import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';

import {
  IonHeader,
  IonToolbar,
  IonTitle,
  IonButtons,
  IonBackButton,
  IonContent,
  IonList,
  IonItem,
  IonLabel,
  IonButton
} from '@ionic/angular/standalone';

import { RouterLink } from '@angular/router';

import { ProductService } from '../services/product';
import { CartService } from '../services/cart';

@Component({
  selector: 'app-vue50',
  standalone: true,
  templateUrl: './vue50.page.html',
  styleUrls: ['./vue50.page.scss'],
  imports: [
    CommonModule,
    RouterLink,
    IonHeader,
    IonToolbar,
    IonTitle,
    IonButtons,
    IonBackButton,
    IonContent,
    IonList,
    IonItem,
    IonLabel,
    IonButton
  ]
})
export class Vue50Page implements OnInit {

  products: any[] = [];

  constructor(
    private productService: ProductService,
    public cartService: CartService     // ← IMPORTANT : injection du panier
  ) {}

  ngOnInit() {
    this.productService.getAllProducts().subscribe({
      next: (data) => {
        console.log("TOUS LES PRODUITS :", data);

        // Filtrer par category = 0 (Poissons)
        this.products = data.filter((p: any) => p.category === 0);

        console.log("Catégorie 0 (Poissons) :", this.products);
      },
      error: (err) => {
        console.error("Erreur API :", err);
      }
    });
  }

  onProductClick(product: any) {
    console.log("Produit cliqué :", product);
  }

  addToCart(product: any) {
    this.cartService.addToCart(product);
    console.log("Ajouté au panier :", product);
  }
}
